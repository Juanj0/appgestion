<?php

return array(


    'pdf' => array(
        'enabled' => true,
        'binary' => 'C:\xampp_56\wkhtmltopdf\bin\wkhtmltopdf.exe',
        'timeout' => false,
        'options' => array(),
    ),
    'image' => array(
        'enabled' => true,
        'binary' => 'C:\xampp_56\wkhtmltopdf\bin\wkhtmltoimage.exe',
        'timeout' => false,
        'options' => array(),
    ),


);
